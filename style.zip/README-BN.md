# Janani Pharmacy — সেটআপ নির্দেশিকা

এটি Janani Pharmacy-এর একটি **প্রাথমিক ওয়েব অ্যাপ স্টার্টার**। এতে লগইন, Owner/Employee role, ওষুধের স্টক, Batch/Expiry, কেনা-বেচা, Activity Log এবং প্রাথমিক রিপোর্ট আছে।

## গুরুত্বপূর্ণ সীমাবদ্ধতা
- ZIP ফাইলটি নিজে থেকে অনলাইনে প্রকাশিত ওয়েবসাইট নয়। Hosting-এ deploy করতে হবে।
- প্রথম Owner অ্যাকাউন্ট তৈরির জন্য Hosting-এর Environment Variables সেট করতে হবে।
- ডেমো/পরীক্ষা ছাড়া বাস্তব ফার্মেসির হিসাব চালুর আগে ব্যাকআপ, নিরাপত্তা, হিসাবের নিয়ম এবং স্থানীয় আইন/লাইসেন্স-সংক্রান্ত প্রয়োজনীয়তা যাচাই করুন।
- লাভের হিসাবটি আনুমানিক gross profit; ভাড়া, বেতন, ছাড়, ফেরত, কর, মেয়াদোত্তীর্ণ ক্ষতি ও অন্যান্য ব্যয় এতে ধরা হয়নি।
- বর্তমান স্টার্টারে image upload, barcode scanner, supplier ledger, customer credit, sales return, purchase return, tax/VAT, multi-branch, automated cloud backup, password reset ও বিস্তারিত audit controls নেই।
- Employee-রা employee account তৈরি করতে পারে, কিন্তু employee deactivate কেবল Owner করতে পারে। Owner-এর নিজের অ্যাকাউন্ট employee-রা deactivate করতে পারে না।
- সবাই purchase/selling price দেখতে ও পরিবর্তন করতে পারে; সব পরিবর্তন Activity Log-এ রেকর্ড হয়।
- এই সংস্করণে user access role ও session আছে, কিন্তু hosting configuration সঠিক না হলে secure production deployment হবে না।

## Owner অ্যাকাউন্ট
Hosting-এর Environment Variables-এ সেট করুন:
- `OWNER_NAME`
- `OWNER_USERNAME`
- `OWNER_PASSWORD` (কমপক্ষে ১০ অক্ষরের শক্তিশালী পাসওয়ার্ড)
- `SESSION_SECRET` (দীর্ঘ random secret)
- `DATABASE_FILE` (যেমন persistent disk-এ `/var/data/janani.sqlite`)

প্রথমবার চালু হলে ডাটাবেসে Owner account তৈরি হবে। **কোনো ডিফল্ট পাসওয়ার্ড নেই।**

## লোকাল চালানো
Node.js 20+ প্রয়োজন:
1. `npm install`
2. `.env.example` কপি করে `.env` বানান এবং নিজের secret/password বসান।
3. `npm start`
4. ব্রাউজারে `http://localhost:3000`

## Hosting-এ চালানো
Node.js hosting ব্যবহার করুন। SQLite ডাটাবেসের জন্য persistent disk/volume যুক্ত করুন এবং `DATABASE_FILE` সেই disk-এর path-এ দিন। Hosting-এ HTTPS বাধ্যতামূলক করুন, `NODE_ENV=production` সেট করুন, এবং দীর্ঘ random `SESSION_SECRET` ব্যবহার করুন। Hosting provider-এর বর্তমান নির্দেশনা অনুসরণ করুন।

iPhone থেকে ZIP ফাইলটি একা deploy করা কঠিন হতে পারে; প্রথম deploy-এ একজন বিশ্বস্ত প্রাপ্তবয়স্ক/প্রযুক্তি-জানা ব্যক্তির সাহায্য নিন। কোনো Gmail password বা OTP কারও সঙ্গে শেয়ার করবেন না।
